<!-- Please enter the info below -->
```
[ ] Bug
[ ] Feature request

CountUp.js version:

```

## Description

<!-- If this is a bug, provide steps to reproduce the issue. -->
<!-- If this is a feature request, describe the use case. -->
